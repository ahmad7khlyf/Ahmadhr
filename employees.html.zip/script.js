// تصدير إلى Excel
function exportToExcel() {
    let table = document.getElementById("employeeTable");
    let workbook = XLSX.utils.table_to_book(table);
    XLSX.writeFile(workbook, "employee_data.xlsx");
}

// تصدير إلى PDF
function exportToPDF() {
    let { jsPDF } = window.jspdf;
    let doc = new jsPDF();
    doc.text("قائمة الموظفين", 10, 10);
    doc.autoTable({ html: "#employeeTable" });
    doc.save("employee_data.pdf");
}

// طباعة الجدول
function printTable() {
    let table = document.getElementById("employeeTable").outerHTML;
    let newWin = window.open("");
    newWin.document.write("<html><head><title>طباعة</title></head><body>" + table + "</body></html>");
    newWin.print();
    newWin.close();
}

// فلترة البيانات
document.getElementById("searchInput").addEventListener("keyup", function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll("#employeeTable tbody tr");
    
    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? "" : "none";
    });
});